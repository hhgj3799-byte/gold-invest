import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import type { DepositGuideStep, PlatformSettings, SupportedAsset } from '../src/types/platform.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'platform.db');
export const db = new DatabaseSync(DB_PATH);

db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

export const DEFAULT_DEPOSIT_STEPS: DepositGuideStep[] = [
  {
    step: 1,
    title: 'Select Payment Method',
    description: 'Choose Nagad (P2P), Binance (P2P), or Trust Wallet USDT (TRC-20 / BEP-20).',
  },
  {
    step: 2,
    title: 'Send Activation or Plan Amount',
    description: 'Transfer 40 BDT ($0.40) for Account Activation or the exact VIP 1–7 tier amount.',
  },
  {
    step: 3,
    title: 'Save Transaction ID',
    description: 'Copy the Transaction ID / TxHash from your Nagad, Binance, or Trust Wallet receipt.',
  },
  {
    step: 4,
    title: 'Submit Proof for Verification',
    description: 'Submit your TxID so the administrator receives an instant approval notification.',
  },
  {
    step: 5,
    title: 'Manual Admin Activation',
    description: 'An administrator reviews your proof and activates your account or VIP tier promptly.',
  },
];

export const DEFAULT_SETTINGS: PlatformSettings = {
  brandName: 'Aurum Global Investments',
  brandTagline: 'Multi-Asset & Precious Metals Yield Platform',
  heroHeadline: 'VIP 1–7 Multi-Asset Investment & Daily Ad Rewards',
  heroSubheadline:
    'Earn $0.01 daily ($0.20 estimated monthly) per $1 invested across VIP Levels 1 to 7, plus daily ad viewing rewards and 10% referral commissions.',
  announcementBanner:
    'Account activation requires a one-time 40 BDT ($0.40) verification fee via Nagad, Binance P2P, or Trust Wallet (TRC20 / BEP20).',
  extraBonusNotice:
    'Additional trading bonuses may be distributed to active VIP holders whenever platform trading generates surplus profit.',
  supportEmail: 'support@aurumcapital.example',
  telegramUrl: 'https://t.me/aurumcapital_official',
  minWithdrawalUsd: 1,
  referralCommissionPct: 10,
  activationFeeBdt: 40,
  activationFeeUsd: 0.4,
  defaultAdRewardUsd: 0.02,
  depositGuideSteps: DEFAULT_DEPOSIT_STEPS,
};

function ensureColumn(tableName: string, columnName: string, definition: string): void {
  const columns = db.prepare(`PRAGMA table_info(${tableName})`).all() as Array<{ name: string }>;
  if (!columns.some((col) => col.name === columnName)) {
    db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition};`);
  }
}

export function initDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      phone_number TEXT NOT NULL DEFAULT '',
      full_name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      is_verified INTEGER NOT NULL DEFAULT 1,
      activation_status TEXT NOT NULL DEFAULT 'Unpaid',
      is_blocked INTEGER NOT NULL DEFAULT 0,
      funds_frozen INTEGER NOT NULL DEFAULT 0,
      otp_hash TEXT,
      otp_expires_at INTEGER,
      otp_attempts INTEGER NOT NULL DEFAULT 0,
      referral_code TEXT UNIQUE NOT NULL,
      referred_by_user_id TEXT,
      balance_usd REAL NOT NULL DEFAULT 0,
      total_invested_usd REAL NOT NULL DEFAULT 0,
      total_earned_usd REAL NOT NULL DEFAULT 0,
      total_referral_earned_usd REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS vip_plans (
      id TEXT PRIMARY KEY,
      tier_number INTEGER NOT NULL,
      name TEXT NOT NULL,
      subtitle TEXT NOT NULL,
      amount_usd REAL NOT NULL,
      daily_rate_per_dollar REAL NOT NULL DEFAULT 0.01,
      monthly_rate_per_dollar REAL NOT NULL DEFAULT 0.20,
      supported_assets TEXT NOT NULL,
      duration_label TEXT NOT NULL DEFAULT 'No Fixed Duration',
      is_active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS payment_methods (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      network TEXT NOT NULL,
      wallet_address TEXT NOT NULL,
      instructions TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS platform_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS activation_requests (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      payment_method_id TEXT NOT NULL,
      payment_method_name TEXT NOT NULL,
      amount_label TEXT NOT NULL,
      amount_usd REAL NOT NULL,
      tx_id TEXT NOT NULL,
      sender_account TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Pending',
      admin_note TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      reviewed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS deposits (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      plan_id TEXT,
      plan_name TEXT,
      selected_asset TEXT NOT NULL,
      payment_method_id TEXT NOT NULL,
      payment_method_name TEXT NOT NULL,
      amount_usd REAL NOT NULL,
      tx_id TEXT NOT NULL,
      sender_note TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Pending',
      admin_note TEXT NOT NULL DEFAULT '',
      reviewed_by TEXT,
      reviewed_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS investments (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      plan_id TEXT NOT NULL,
      plan_name TEXT NOT NULL,
      selected_asset TEXT NOT NULL,
      amount_usd REAL NOT NULL,
      daily_income_usd REAL NOT NULL,
      source_deposit_id TEXT,
      status TEXT NOT NULL DEFAULT 'Active',
      last_claimed_date TEXT,
      total_earned_usd REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS earnings_records (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      asset TEXT NOT NULL DEFAULT '',
      amount_usd REAL NOT NULL,
      reference_id TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS task_records (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      investment_id TEXT NOT NULL,
      plan_name TEXT NOT NULL,
      asset TEXT NOT NULL,
      task_title TEXT NOT NULL,
      reward_usd REAL NOT NULL,
      status TEXT NOT NULL,
      task_date TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS financial_records (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      direction TEXT NOT NULL,
      amount_usd REAL NOT NULL,
      balance_after_usd REAL NOT NULL,
      status TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS withdrawals (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      payment_method_name TEXT NOT NULL,
      wallet_address TEXT NOT NULL,
      amount_usd REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending',
      admin_note TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      reviewed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS ads (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      target_url TEXT NOT NULL,
      reward_usd REAL NOT NULL DEFAULT 0.02,
      duration_seconds INTEGER NOT NULL DEFAULT 5,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ad_claims (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      ad_id TEXT NOT NULL,
      claim_date TEXT NOT NULL,
      reward_usd REAL NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(user_id, ad_id, claim_date)
    );

    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      sender_role TEXT NOT NULL,
      sender_email TEXT NOT NULL,
      subject TEXT NOT NULL DEFAULT '',
      body TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
  `);

  // Safe schema migrations for existing persisted SQLite DBs
  ensureColumn('users', 'phone_number', "TEXT NOT NULL DEFAULT ''");
  ensureColumn('users', 'activation_status', "TEXT NOT NULL DEFAULT 'Unpaid'");
  ensureColumn('users', 'is_blocked', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('users', 'funds_frozen', 'INTEGER NOT NULL DEFAULT 0');
  ensureColumn('vip_plans', 'monthly_rate_per_dollar', 'REAL NOT NULL DEFAULT 0.20');

  seedDefaults();
}

function seedDefaults(): void {
  const defaultAssets: SupportedAsset[] = ['Gold', 'USD', 'Apple', 'Meta', 'Tesla'];
  const upsertPlan = db.prepare(`
    INSERT OR IGNORE INTO vip_plans (id, tier_number, name, subtitle, amount_usd, daily_rate_per_dollar, monthly_rate_per_dollar, supported_assets, duration_label, is_active, sort_order)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
  `);

  const tiers = [
    { id: 'vip-1', tier: 1, name: 'VIP 1', subtitle: 'Starter Reserve Allocation', amount: 1 },
    { id: 'vip-2', tier: 2, name: 'VIP 2', subtitle: 'Core Multi-Asset Position', amount: 2 },
    { id: 'vip-3', tier: 3, name: 'VIP 3', subtitle: 'Balanced Equity & Gold Tier', amount: 3 },
    { id: 'vip-4', tier: 4, name: 'VIP 4', subtitle: 'Growth Portfolio Allocation', amount: 4 },
    { id: 'vip-5', tier: 5, name: 'VIP 5', subtitle: 'Premier Executive Reserve', amount: 5 },
    { id: 'vip-6', tier: 6, name: 'VIP 6', subtitle: 'Institutional Gold Desk', amount: 10 },
    { id: 'vip-7', tier: 7, name: 'VIP 7', subtitle: 'Sovereign Bullion Syndicate', amount: 20 },
  ];

  for (const t of tiers) {
    upsertPlan.run(
      t.id,
      t.tier,
      t.name,
      t.subtitle,
      t.amount,
      0.01,
      0.2,
      JSON.stringify(defaultAssets),
      'No Fixed Duration',
      t.tier
    );
  }

  // Strictly configure Nagad (P2P), Binance (P2P), Trust Wallet (TRC20), and Trust Wallet (BEP20)
  const pmRows = db.prepare('SELECT id FROM payment_methods').all() as Array<{ id: string }>;
  const existingIds = new Set(pmRows.map((r) => r.id));
  const hasOnlyLegacyDefaults =
    pmRows.length > 0 &&
    pmRows.every((r) => r.id === 'pm-binance-trc20' || r.id === 'pm-trustwallet-trc20');

  if (pmRows.length === 0 || hasOnlyLegacyDefaults) {
    if (hasOnlyLegacyDefaults) {
      db.exec('DELETE FROM payment_methods;');
    }
    const insertPm = db.prepare(`
      INSERT INTO payment_methods (id, name, network, wallet_address, instructions, is_active, sort_order)
      VALUES (?, ?, ?, ?, ?, 1, ?)
    `);
    insertPm.run(
      'pm-nagad-p2p',
      'Nagad (P2P)',
      'Nagad Personal / P2P (BDT)',
      '+8801700000400',
      'Open Nagad App -> Send Money to this P2P number -> Transfer 40 BDT for activation or VIP amount (1 USD ≈ 120 BDT) -> Paste Nagad TrxID.',
      1
    );
    insertPm.run(
      'pm-binance-p2p',
      'Binance (P2P)',
      'Binance Pay / P2P UID',
      'BINANCE-P2P-84920144',
      'Open Binance App -> Pay / P2P Transfer -> Send USDT to this Binance Pay ID / P2P UID -> Paste the Binance Order / TxID.',
      2
    );
    insertPm.run(
      'pm-trustwallet-trc20',
      'Trust Wallet (USDT TRC-20)',
      'TRC-20 (Tron)',
      'TVj7RNVHy6thbM7BWdSe9G6gHkKhj5h6eF',
      'Open Trust Wallet -> Select USDT (TRC20 / Tron) -> Send exact USD amount -> Paste the TRC-20 Transaction Hash.',
      3
    );
    insertPm.run(
      'pm-trustwallet-bep20',
      'Trust Wallet (USDT BEP-20)',
      'BEP-20 (BNB Smart Chain)',
      '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
      'Open Trust Wallet -> Select USDT (BEP20 / BSC) -> Send exact USD amount -> Paste the BEP-20 Transaction Hash.',
      4
    );
  } else if (!existingIds.has('pm-nagad-p2p') && pmRows.length < 4) {
    // Ensure missing strict methods exist if only partial set is present
    const insertMissing = db.prepare(`
      INSERT OR IGNORE INTO payment_methods (id, name, network, wallet_address, instructions, is_active, sort_order)
      VALUES (?, ?, ?, ?, ?, 1, ?)
    `);
    insertMissing.run(
      'pm-nagad-p2p',
      'Nagad (P2P)',
      'Nagad Personal / P2P (BDT)',
      '+8801700000400',
      'Send Money via Nagad P2P and submit your Transaction ID.',
      1
    );
    insertMissing.run(
      'pm-binance-p2p',
      'Binance (P2P)',
      'Binance Pay / P2P UID',
      'BINANCE-P2P-84920144',
      'Transfer via Binance P2P / Pay ID and submit your Order / TxID.',
      2
    );
    insertMissing.run(
      'pm-trustwallet-bep20',
      'Trust Wallet (USDT BEP-20)',
      'BEP-20 (BNB Smart Chain)',
      '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
      'Send USDT on BEP-20 (BSC) via Trust Wallet and submit your TxHash.',
      4
    );
  }

  // Seed default daily ads if empty
  const adsCount = (db.prepare('SELECT COUNT(*) as count FROM ads').get() as { count: number }).count;
  if (adsCount === 0) {
    const insertAd = db.prepare(`
      INSERT INTO ads (id, title, description, target_url, reward_usd, duration_seconds, is_active, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 1, ?)
    `);
    const nowIso = new Date().toISOString();
    insertAd.run(
      'ad-gold-desk',
      '24K Bullion Liquidity Briefing',
      'Review today’s global gold reserve liquidity update and earn an instant ad reward.',
      'https://t.me/aurumcapital_official',
      0.02,
      5,
      nowIso
    );
    insertAd.run(
      'ad-equities-pulse',
      'Apple, Meta & Tesla Market Dispatch',
      'Explore daily US blue-chip equity yield insights for VIP 1–7 portfolio holders.',
      'https://t.me/aurumcapital_official',
      0.02,
      5,
      nowIso
    );
    insertAd.run(
      'ad-partner-community',
      'Official Telegram Community Spotlight',
      'Stay updated on platform trading bonuses and P2P settlement windows.',
      'https://t.me/aurumcapital_official',
      0.03,
      5,
      nowIso
    );
  }

  const upsertSetting = db.prepare(`
    INSERT OR IGNORE INTO platform_settings (key, value) VALUES (?, ?)
  `);
  upsertSetting.run('brandName', DEFAULT_SETTINGS.brandName);
  upsertSetting.run('brandTagline', DEFAULT_SETTINGS.brandTagline);
  upsertSetting.run('heroHeadline', DEFAULT_SETTINGS.heroHeadline);
  upsertSetting.run('heroSubheadline', DEFAULT_SETTINGS.heroSubheadline);
  upsertSetting.run('announcementBanner', DEFAULT_SETTINGS.announcementBanner);
  upsertSetting.run('extraBonusNotice', DEFAULT_SETTINGS.extraBonusNotice);
  upsertSetting.run('supportEmail', DEFAULT_SETTINGS.supportEmail);
  upsertSetting.run('telegramUrl', DEFAULT_SETTINGS.telegramUrl);
  upsertSetting.run('minWithdrawalUsd', String(DEFAULT_SETTINGS.minWithdrawalUsd));
  upsertSetting.run('referralCommissionPct', String(DEFAULT_SETTINGS.referralCommissionPct));
  upsertSetting.run('activationFeeBdt', String(DEFAULT_SETTINGS.activationFeeBdt));
  upsertSetting.run('activationFeeUsd', String(DEFAULT_SETTINGS.activationFeeUsd));
  upsertSetting.run('defaultAdRewardUsd', String(DEFAULT_SETTINGS.defaultAdRewardUsd));
  upsertSetting.run('depositGuideSteps', JSON.stringify(DEFAULT_SETTINGS.depositGuideSteps));

  // Migrate old VIP 1-5 default copy if it still has the old placeholder string
  const heroSubRow = db
    .prepare("SELECT value FROM platform_settings WHERE key = 'heroSubheadline'")
    .get() as { value: string } | undefined;
  if (heroSubRow && heroSubRow.value.includes('VIP 1 to VIP 5')) {
    db.prepare("UPDATE platform_settings SET value = ? WHERE key = 'heroSubheadline'").run(
      DEFAULT_SETTINGS.heroSubheadline
    );
    db.prepare("UPDATE platform_settings SET value = ? WHERE key = 'brandName'").run(
      DEFAULT_SETTINGS.brandName
    );
    db.prepare("UPDATE platform_settings SET value = ? WHERE key = 'heroHeadline'").run(
      DEFAULT_SETTINGS.heroHeadline
    );
    db.prepare("UPDATE platform_settings SET value = ? WHERE key = 'announcementBanner'").run(
      DEFAULT_SETTINGS.announcementBanner
    );
    db.prepare("UPDATE platform_settings SET value = ? WHERE key = 'depositGuideSteps'").run(
      JSON.stringify(DEFAULT_SETTINGS.depositGuideSteps)
    );
  }
}

export function getPlatformSettings(): PlatformSettings {
  const rows = db.prepare('SELECT key, value FROM platform_settings').all() as Array<{
    key: string;
    value: string;
  }>;
  const map = new Map(rows.map((r) => [r.key, r.value]));

  let steps = DEFAULT_DEPOSIT_STEPS;
  try {
    const rawSteps = map.get('depositGuideSteps');
    if (rawSteps) {
      const parsed = JSON.parse(rawSteps);
      if (Array.isArray(parsed) && parsed.length > 0) steps = parsed;
    }
  } catch {
    steps = DEFAULT_DEPOSIT_STEPS;
  }

  return {
    brandName: map.get('brandName') ?? DEFAULT_SETTINGS.brandName,
    brandTagline: map.get('brandTagline') ?? DEFAULT_SETTINGS.brandTagline,
    heroHeadline: map.get('heroHeadline') ?? DEFAULT_SETTINGS.heroHeadline,
    heroSubheadline: map.get('heroSubheadline') ?? DEFAULT_SETTINGS.heroSubheadline,
    announcementBanner: map.get('announcementBanner') ?? DEFAULT_SETTINGS.announcementBanner,
    extraBonusNotice: map.get('extraBonusNotice') ?? DEFAULT_SETTINGS.extraBonusNotice,
    supportEmail: map.get('supportEmail') ?? DEFAULT_SETTINGS.supportEmail,
    telegramUrl: map.get('telegramUrl') ?? DEFAULT_SETTINGS.telegramUrl,
    minWithdrawalUsd: Number(map.get('minWithdrawalUsd') ?? DEFAULT_SETTINGS.minWithdrawalUsd) || 1,
    referralCommissionPct:
      Number(map.get('referralCommissionPct') ?? DEFAULT_SETTINGS.referralCommissionPct) || 10,
    activationFeeBdt: Number(map.get('activationFeeBdt') ?? DEFAULT_SETTINGS.activationFeeBdt) || 40,
    activationFeeUsd: Number(map.get('activationFeeUsd') ?? DEFAULT_SETTINGS.activationFeeUsd) || 0.4,
    defaultAdRewardUsd:
      Number(map.get('defaultAdRewardUsd') ?? DEFAULT_SETTINGS.defaultAdRewardUsd) || 0.02,
    depositGuideSteps: steps,
  };
}
